#include <iostream>
#include <string>
#include <fstream>
using namespace std;
//
class Book{
public:
    string Title;
    string Shelf_Number;
    string Authors;
    string Edition;
    string Publisher;
    string Published_year;
    string ISBN;
    string Length;
    string Subjects;
    string Available;

    Book(string title, string shelf_number ,string authors, string edition, string publisher, string published_year, string isbn, string length, string subjects, string available){
        Title = title;
        Shelf_Number = shelf_number;
        Authors = authors;
        Edition = edition;
        Publisher = publisher;
        Published_year = published_year;
        ISBN = isbn;
        Length = length;
        Subjects = subjects;
        Available = available;
    }
    string getTitle() {return Title;}
    string getShelf_number() {return Shelf_Number;}
    string getAuthors() {return Authors;}
    string getEdition() {return Edition;}
    string getPublisher() {return Publisher;}
    string getPublished_year() {return Published_year;}
    string getISBN() {return ISBN;}
    string getLenght() {return Length;}
    string getSubjects() {return Subjects;}
};
//
class Patron{
public:
    string Username;
    string Password;
    string Firstname;
    string Lastname;
    string Birthdate;

    Patron(string username, string password, string firstname, string lastname, string birthdate){
        Username = username;
        Password = password;
        Firstname = firstname;
        Lastname = lastname;
        Birthdate = birthdate;
    }
    string getUserame() {return Username;}
    string getPassword() {return Password;}
    string getFirstname() {return Firstname;}
    string getLastname() {return Lastname;}
    string getBirthdate() {return Birthdate;}
};
//
int main() {
    string book[100][11];
    string user[100][5];
    int number[100];
    int x = 10;
    int iter_1 = 0;
    int iter_2 = 0;
    while(x){
        cout << "What you wanna do:" << endl << "1. Register new user" << endl << "2. Login" << endl << "3. Add book" << endl << "4. Exit" << endl;
        cin >> x;
        if(x == 1){
            string u, p, f, l, b;
            cout << "Enter Username:" << endl;
            cin >> u;
            user[iter_1][0] = u;
            cout << "Enter Password:" << endl;
            cin >> p;
            user[iter_1][1] = p;
            cout << "Enter Firstname:" << endl;
            cin >> f;
            user[iter_1][2] = f;
            cout << "Enter Lastname:" << endl;
            cin >> l;
            user[iter_1][3] = l;
            cout << "Enter Birthdate(MM/DD/YYYY):" << endl;
            cin >> b;
            user[iter_1][4] = b;
            number[iter_1] = 0;
            Patron p1(u, p, f, l, b);
            iter_1++;
            ofstream userFile("users.txt", ios::app);
            userFile << p1.Username << "," << p1.Password << "," << p1.Firstname << "," << p1.Lastname << "," << p1.Birthdate << endl;
            userFile.close();
            cout << "Register successfully" << endl;
        }
        else if(x == 2){
            string u1, p1;
            cout << "Enter Username:" << endl;
            cin >> u1;
            cout << "Enter Password:" << endl;
            cin >> p1;
            int z = 0;
            for(int i = 0; i < iter_1; i++){
                if(u1 == user[i][0] and p1 == user[i][1]){
                    cout << "Login successfully." << endl;
                    z = i;
                    int y2 = 10;
                    while(y2){
                        cout << "Which operation you want to do:" << endl << "1. Search for a book" << endl << "2. Rent book" << endl << "3. Return book" << endl << "4. Back" << endl;
                        cin >> y2;
                        if(y2 == 1){
                            z++;
                            string searchCriteria, searchTerm;
                            cout << "Enter search criteria (title, author, publisher, year): " << endl;
                            cin >> searchCriteria;
                            cout << "Enter search term: " << endl;
                            cin >> searchTerm;
                            int fo = 0;
                            for(int i = 0; i < iter_2; i++){
                                if (searchCriteria == "title" && book[i][0] == searchTerm) {
                                    cout << book[i][0] << " " << book[i][1] << " " << book[i][2] << " " << book[i][3] << " " << book[i][4] << " " <<
                                    book[i][5] << " " << book[i][6] << " " << book[i][7] << " " << book[i][8] << " " << book[i][9] << " " << book[i][10] << endl;
                                    fo++;
                                }
                                else if (searchCriteria == "author" && book[i][2] == searchTerm) {
                                    cout << book[i][0] << " " << book[i][1] << " " << book[i][2] << " " << book[i][3] << " " << book[i][4] << " " <<
                                    book[i][5] << " " << book[i][6] << " " << book[i][7] << " " << book[i][8] << " " << book[i][9] << " " << book[i][10] <<endl;
                                    fo++;
                                }
                                else if (searchCriteria == "publisher" && book[i][4] == searchTerm) {
                                    cout << book[i][0] << " " << book[i][1] << " " << book[i][2] << " " << book[i][3] << " " << book[i][4] << " " <<
                                    book[i][5] << " " << book[i][6] << " " << book[i][7] << " " << book[i][8] << " " << book[i][9] << " " << book[i][10] <<endl;
                                    fo++;
                                }
                                else if (searchCriteria == "year" && book[i][5] == searchTerm) {
                                    cout << book[i][0] << " " << book[i][1] << " " << book[i][2] << " " << book[i][3] << " " << book[i][4] << " " <<
                                    book[i][5] << " " << book[i][6] << " " << book[i][7] << " " << book[i][8] << " " << book[i][9] << " " << book[i][10] <<endl;
                                    fo++;
                                }
                            }
                            if(fo == 0)
                                cout << "Book not found!" << endl;
                        }
                        if(y2 == 2){
                            z++;
                            string bookname;
                            cout << "Enter book title: " << endl;
                            cin >> bookname;
                            for(int i = 0; i < iter_2; i++){
                                if (book[i][0] == bookname){
                                    if(book[i][9] == "free"){
                                        number[iter_1]++;
                                        if(number[iter_1] != 3){
                                            cout << "Rented successfully!" << endl;
                                            book[i][9] = "rented";
                                            book[i][10] = user[iter_1][0];
                                        }
                                        else{
                                            cout << "This user already rented 2 books!" << endl;
                                        }
                                    }
                                    else{
                                        cout << "This book is rented by another user!" << endl;
                                    }
                                }
                            }
                        }
                        if(y2 == 3){
                            z++;
                            string bookname1;
                            cout << "Enter book title you want to return: " << endl;
                            cin >> bookname1;
                            for(int i = 0; i < iter_2; i++){
                                if(book[i][0] == bookname1){
                                    cout << "Returned successfully!" << endl;
                                    book[i][9] = "free";
                                    book[i][10] = "NULL";
                                    number[iter_1]--;
                                }
                            }
                        }
                        if(y2 == 4){
                            z++;
                            y2 = 0;
                        }
                    }
                }
            }
            if(z == 0){
                cout << "Invalid data." << endl;
            }
        }
        else if(x == 3){
            string t, a, sh, e, p, p_y, i, l, s, A, N;
            cout << "Enter book data:" << endl;
            cin >> t >> a >> sh >> e >> p >> p_y >> i >> l >> s >> A >> N;
            Book b1(t, a, sh, e, p, p_y, i, l, s, A);
            book[iter_2][0] = t;book[iter_2][1] = a;book[iter_2][2] = sh;book[iter_2][3] = e;book[iter_2][4] = p;book[iter_2][5] = p_y;
            book[iter_2][6] = i;book[iter_2][7] =l;book[iter_2][8] = s;book[iter_2][9] = A;book[iter_2][10] = N;
            iter_2++;
            ofstream bookFile("books.txt", ios::app);
            bookFile << b1.Title << "," << b1.Shelf_Number << "," << b1.Authors << "," << b1.Edition << "," << b1.Publisher << "," << b1.Published_year <<
            "," << b1.ISBN << "," << b1.Length << "," << b1.Subjects << "," << b1.Available << endl;
            bookFile.close();
            cout << "Added successfully!" << endl;
        }
        else if(x == 4){
            x = 0;
        }
    }
    return 0;
}
